import { motion } from 'framer-motion';
import Link from 'next/link';

export default function ThankYouPage() {
  return (
    <main className="min-h-screen bg-gray-200 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Link href="/" className="text-purple-700 hover:text-purple-900 font-bold text-xl">
            HOMO TECH
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7 }}
          className="bg-white rounded-lg shadow-lg p-8 text-center"
        >
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
          >
            <h1 className="text-4xl font-bold text-purple-700 mb-6">Thank You!</h1>
            <p className="text-xl mb-8">
              Your response has been recorded. Thank you for contributing to our database about AI's impact.
            </p>
            <p className="text-lg mb-6">
              Remember, as Marie Curie said: "Nothing in life is to be feared, it is only to be understood. 
              Now is the time to understand more, so that we may fear less."
            </p>
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="inline-block"
            >
              <Link href="/" className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300">
                Return to Home
              </Link>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </main>
  );
}
