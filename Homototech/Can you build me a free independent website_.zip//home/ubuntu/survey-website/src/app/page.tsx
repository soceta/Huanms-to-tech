'use client';

import { useEffect } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function Home() {
  // Add skip to content functionality
  useEffect(() => {
    const skipLink = document.getElementById('skip-to-content');
    if (skipLink) {
      skipLink.addEventListener('click', (e) => {
        e.preventDefault();
        const mainContent = document.getElementById('main-content');
        if (mainContent) {
          mainContent.focus();
          mainContent.scrollIntoView();
        }
      });
    }
  }, []);

  return (
    <>
      <a id="skip-to-content" href="#main-content" className="skip-to-content">
        Skip to main content
      </a>
      
      <main id="main-content" tabIndex={-1} className="flex min-h-screen flex-col items-center justify-center bg-purple-500 p-4 text-center">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="max-w-4xl mx-auto"
        >
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <h1 className="text-4xl sm:text-6xl font-bold text-black mb-4" aria-label="HOMO TECH">HOMO TECH</h1>
            <div className="bg-purple-300 bg-opacity-50 rounded-lg p-4 mb-8">
              <h2 className="text-xl sm:text-2xl text-black">Welcome to the first record about AI's impact</h2>
            </div>
          </motion.div>

          <div className="relative w-full max-w-xl mx-auto mb-12">
            <div className="absolute inset-0 bg-white opacity-20 rounded-full"></div>
            <div className="relative z-10">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.8 }}
                className="text-center"
              >
                <Link href="/survey" aria-label="Take the survey">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="bg-purple-300 hover:bg-purple-400 text-black font-bold py-4 px-8 rounded-full text-xl transition-all duration-300"
                  >
                    TAKE THE SURVEY
                  </motion.button>
                </Link>
              </motion.div>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="bg-purple-300 bg-opacity-50 rounded-lg p-6 max-w-2xl mx-auto"
          >
            <blockquote className="italic text-lg text-black">
              "Nothing in life is to be feared, it is only to be understood. Now is the time to understand more, so that we may fear less."
              <footer className="text-right mt-2 font-bold">Marie Curie</footer>
            </blockquote>
          </motion.div>
        </motion.div>
      </main>
    </>
  );
}
