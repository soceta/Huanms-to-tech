import { NextResponse } from 'next/server';
import { saveSurveyResponse, SurveyResponse } from '@/lib/supabase';

export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    // Transform form data to match database schema
    const surveyResponse: SurveyResponse = {
      name: data.name,
      dob_day: data.dob.day,
      dob_month: data.dob.month,
      dob_year: data.dob.year,
      gender: data.gender,
      gender_other: data.genderOther || null,
      education: data.education || null,
      education_other: data.educationOther || null,
      email: data.email || null,
      first_time: data.firstTime,
      added_tech: data.addedTech,
      added_tech_other: data.addedTechOther || null,
      added_tech_comments: data.addedTechComments || null,
      agree_to_add: data.agreeToAdd,
      agree_to_add_comments: data.agreeToAddComments || null,
      fear_level: data.fearLevel,
    };
    
    // Save to Supabase
    const response = await saveSurveyResponse(surveyResponse);
    
    return NextResponse.json({ success: true, data: response });
  } catch (error) {
    console.error('Error submitting survey:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to submit survey' },
      { status: 500 }
    );
  }
}
