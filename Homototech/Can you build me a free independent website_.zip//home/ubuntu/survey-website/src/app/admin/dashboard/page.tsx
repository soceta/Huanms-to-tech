'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { getSurveyResponses } from '@/lib/supabase';

export default function AdminDashboard() {
  const [responses, setResponses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [sortField, setSortField] = useState('created_at');
  const [sortDirection, setSortDirection] = useState('desc');
  const [filterTerm, setFilterTerm] = useState('');

  useEffect(() => {
    const fetchResponses = async () => {
      try {
        const data = await getSurveyResponses();
        setResponses(data);
      } catch (error) {
        console.error('Error fetching responses:', error);
        setError('Failed to load survey responses. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchResponses();
  }, []);

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const filteredResponses = responses.filter(response => {
    if (!filterTerm) return true;
    const searchTerm = filterTerm.toLowerCase();
    return (
      (response.name && response.name.toLowerCase().includes(searchTerm)) ||
      (response.email && response.email.toLowerCase().includes(searchTerm)) ||
      (response.added_tech && response.added_tech.toLowerCase().includes(searchTerm)) ||
      (response.agree_to_add && response.agree_to_add.toLowerCase().includes(searchTerm))
    );
  });

  const sortedResponses = [...filteredResponses].sort((a, b) => {
    if (a[sortField] === null) return 1;
    if (b[sortField] === null) return -1;
    
    if (sortField === 'created_at' || sortField === 'fear_level') {
      const aValue = sortField === 'fear_level' ? parseInt(a[sortField]) : new Date(a[sortField]);
      const bValue = sortField === 'fear_level' ? parseInt(b[sortField]) : new Date(b[sortField]);
      
      if (sortDirection === 'asc') {
        return aValue - bValue;
      } else {
        return bValue - aValue;
      }
    } else {
      const aValue = a[sortField].toLowerCase();
      const bValue = b[sortField].toLowerCase();
      
      if (sortDirection === 'asc') {
        return aValue.localeCompare(bValue);
      } else {
        return bValue.localeCompare(aValue);
      }
    }
  });

  const exportToCSV = () => {
    // Create CSV header
    const headers = [
      'ID', 'Date', 'Name', 'DOB', 'Gender', 'Education', 'Email', 
      'First Time', 'Added Tech', 'Added Tech Comments', 
      'Agree to Add', 'Agree to Add Comments', 'Fear Level'
    ];
    
    // Create CSV rows
    const rows = sortedResponses.map(response => [
      response.id,
      new Date(response.created_at).toLocaleString(),
      response.name,
      `${response.dob_day} ${response.dob_month} ${response.dob_year}`,
      response.gender_other ? `${response.gender} (${response.gender_other})` : response.gender,
      response.education_other ? `${response.education} (${response.education_other})` : response.education,
      response.email || '',
      response.first_time,
      response.added_tech_other ? `${response.added_tech} (${response.added_tech_other})` : response.added_tech,
      response.added_tech_comments || '',
      response.agree_to_add,
      response.agree_to_add_comments || '',
      response.fear_level
    ]);
    
    // Combine header and rows
    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `survey_responses_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <main className="min-h-screen bg-gray-100">
      <div className="bg-purple-600 text-white p-4 shadow-md">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <Link href="/" className="text-xl font-bold">HOMO TECH</Link>
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <div></div> {/* Empty div for flex spacing */}
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-lg shadow-lg p-6 mb-8"
        >
          <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
            <h2 className="text-2xl font-bold mb-4 sm:mb-0">Survey Responses</h2>
            <div className="flex flex-col sm:flex-row gap-4">
              <input
                type="text"
                placeholder="Search responses..."
                value={filterTerm}
                onChange={(e) => setFilterTerm(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <button
                onClick={exportToCSV}
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md transition-colors"
              >
                Export to CSV
              </button>
            </div>
          </div>
          
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              {error}
            </div>
          )}
          
          {isLoading ? (
            <div className="text-center py-8">
              <p className="text-gray-600">Loading survey responses...</p>
            </div>
          ) : sortedResponses.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-600">No survey responses found.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white">
                <thead className="bg-gray-100">
                  <tr>
                    <th 
                      className="px-4 py-2 text-left cursor-pointer hover:bg-gray-200"
                      onClick={() => handleSort('created_at')}
                    >
                      Date {sortField === 'created_at' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th 
                      className="px-4 py-2 text-left cursor-pointer hover:bg-gray-200"
                      onClick={() => handleSort('name')}
                    >
                      Name {sortField === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="px-4 py-2 text-left">Gender</th>
                    <th 
                      className="px-4 py-2 text-left cursor-pointer hover:bg-gray-200"
                      onClick={() => handleSort('added_tech')}
                    >
                      Added Tech {sortField === 'added_tech' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th 
                      className="px-4 py-2 text-left cursor-pointer hover:bg-gray-200"
                      onClick={() => handleSort('agree_to_add')}
                    >
                      Agree to Add {sortField === 'agree_to_add' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th 
                      className="px-4 py-2 text-left cursor-pointer hover:bg-gray-200"
                      onClick={() => handleSort('fear_level')}
                    >
                      Fear Level {sortField === 'fear_level' && (sortDirection === 'asc' ? '↑' : '↓')}
                    </th>
                    <th className="px-4 py-2 text-left">Details</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedResponses.map((response) => (
                    <tr key={response.id} className="border-t hover:bg-gray-50">
                      <td className="px-4 py-2">{new Date(response.created_at).toLocaleString()}</td>
                      <td className="px-4 py-2">{response.name}</td>
                      <td className="px-4 py-2">{response.gender}</td>
                      <td className="px-4 py-2">{response.added_tech}</td>
                      <td className="px-4 py-2">{response.agree_to_add}</td>
                      <td className="px-4 py-2">{response.fear_level}</td>
                      <td className="px-4 py-2">
                        <button
                          onClick={() => alert(`Full details for ${response.name}:\n\n${JSON.stringify(response, null, 2)}`)}
                          className="text-purple-600 hover:text-purple-800 underline"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>
        
        <div className="text-center text-gray-600">
          <p>Total responses: {responses.length}</p>
          <p>Filtered responses: {sortedResponses.length}</p>
        </div>
      </div>
    </main>
  );
}
