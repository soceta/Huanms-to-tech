import { motion } from 'framer-motion';
import Link from 'next/link';

export default function SurveyPage() {
  return (
    <main className="min-h-screen bg-gray-200 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Link href="/" className="text-purple-700 hover:text-purple-900 font-bold text-xl">
            HOMO TECH
          </Link>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-4xl font-bold text-center mb-8"
        >
          TAKE THE SURVEY
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="bg-white rounded-lg shadow-lg p-6 mb-8"
        >
          <p className="text-gray-800 mb-4">
            Dear homo-sapiens, you are most welcome to print your pure neurological feelings with 2 basic, simple questions. 
            This website is mainly about taking a survey from people as a primitive record. All you have to do is to give us 
            1 to 3 minutes from your short life to contribute to this database.
          </p>
          <p className="text-gray-800 mb-4">
            The first question is about whether you agree or don't agree with adding AI supplies to yourself. 
            And the next question is to scale yourself from 0 to 10 for how much fear does this idea "adding AI supplies to yourself" scares you. 
            0 means no fear at all.
          </p>
          <p className="text-gray-800">
            This website reminds you that we are more than feelings, we have the brain that was the reason for AI at the first place. 
            It is totally understandable that this quick development causes fear for many of us, we want to remind ourselves here 
            that things need to be understandable so that it becomes less scary.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.6 }}
          className="bg-white rounded-lg shadow-lg p-6 mb-8"
        >
          <div className="flex justify-center mb-8">
            <div className="w-64 h-64 rounded-full bg-purple-100 flex items-center justify-center overflow-hidden">
              <img 
                src="/robot-human-hands.jpg" 
                alt="A robotic hand reaching out to a human hand" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <p className="text-gray-800 text-center text-xl mb-6">
            What do you feel when a friend or a company asks you to add Techno chips to your brain or nanorobots to your blood? 
            What if you are seeing motivations and ads about this everywhere?
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.8 }}
          className="flex justify-center"
        >
          <Link href="/survey/form">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-4 px-8 rounded-lg text-xl transition-all duration-300"
            >
              TAKE THE SURVEY
            </motion.button>
          </Link>
        </motion.div>
      </div>
    </main>
  );
}
