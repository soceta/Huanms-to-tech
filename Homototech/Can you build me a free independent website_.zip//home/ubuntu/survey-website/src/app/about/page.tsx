'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';

export default function AboutUsPage() {
  return (
    <main className="min-h-screen bg-gray-200 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Link href="/" className="text-purple-700 hover:text-purple-900 font-bold text-xl">
            HOMO TECH
          </Link>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-4xl font-bold text-center mb-8"
        >
          About Us
        </motion.h1>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="bg-white rounded-lg shadow-lg p-6 mb-8"
        >
          <div className="flex justify-center mb-8">
            <div className="w-64 h-64 rounded-full bg-purple-100 flex items-center justify-center overflow-hidden">
              <img 
                src="/brain-ai.jpg" 
                alt="Brain with AI connections" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="prose max-w-none">
            <h2 className="text-2xl font-bold mb-4 text-purple-700">Our Mission</h2>
            <p className="mb-4">
              HOMO TECH is dedicated to creating the first comprehensive record about AI's impact on humanity. 
              We believe that understanding the relationship between humans and technology is crucial as we 
              navigate the rapidly evolving landscape of artificial intelligence.
            </p>
            
            <h2 className="text-2xl font-bold mb-4 text-purple-700">What We Do</h2>
            <p className="mb-4">
              Through our survey, we collect valuable data about people's attitudes, fears, and experiences 
              regarding AI integration with human biology. This primitive record serves as a baseline for 
              understanding how our relationship with technology evolves over time.
            </p>
            
            <p className="mb-4">
              As Marie Curie wisely said: "Nothing in life is to be feared, it is only to be understood. 
              Now is the time to understand more, so that we may fear less." This philosophy guides our 
              approach to studying the intersection of humanity and technology.
            </p>
            
            <h2 className="text-2xl font-bold mb-4 text-purple-700">Our Vision</h2>
            <p className="mb-4">
              We envision a future where the integration of AI and human biology is approached with 
              understanding rather than fear. By collecting data now, we hope to contribute to a more 
              informed discourse about the future of human-AI coexistence.
            </p>
            
            <h2 className="text-2xl font-bold mb-4 text-purple-700">Join Us</h2>
            <p className="mb-4">
              We invite you to be part of this important research by taking our survey and sharing your 
              thoughts about AI integration. Your contribution helps build a more comprehensive understanding 
              of humanity's relationship with technology.
            </p>
            
            <div className="flex justify-center mt-8">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="inline-block"
              >
                <Link href="/survey" className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300">
                  Take the Survey
                </Link>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </main>
  );
}
