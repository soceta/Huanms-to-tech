'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function SurveyForm() {
  const [formData, setFormData] = useState({
    name: '',
    dob: { day: '', month: '', year: '' },
    gender: '',
    genderOther: '',
    education: '',
    educationOther: '',
    email: '',
    firstTime: '',
    addedTech: '',
    addedTechOther: '',
    addedTechComments: '',
    agreeToAdd: '',
    agreeToAddOther: '',
    agreeToAddComments: '',
    fearLevel: '',
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData({
        ...formData,
        [parent]: {
          ...formData[parent],
          [child]: value
        }
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitError('');
    
    try {
      const response = await fetch('/api/submit-survey', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });
      
      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.error || 'Failed to submit survey');
      }
      
      // Redirect to thank you page
      window.location.href = '/survey/thank-you';
    } catch (error) {
      console.error('Error submitting form:', error);
      setSubmitError(error.message || 'An error occurred while submitting the survey. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5 }
    }
  };

  return (
    <main className="min-h-screen bg-gray-200 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Link href="/" className="text-purple-700 hover:text-purple-900 font-bold text-xl">
            HOMO TECH
          </Link>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-4xl font-bold text-center mb-8"
        >
          Homo To Tech
        </motion.h1>

        {submitError && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6"
          >
            {submitError}
          </motion.div>
        )}

        <motion.form
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          onSubmit={handleSubmit}
          className="space-y-8"
        >
          {/* Personal Information Section */}
          <motion.div variants={itemVariants} className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4">Personal Information</h2>
            
            {/* Name */}
            <div className="mb-6">
              <label htmlFor="name" className="block text-gray-700 font-bold mb-2">
                First and last name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
            
            {/* Date of Birth */}
            <div className="mb-6">
              <label className="block text-gray-700 font-bold mb-2">
                Date of birth <span className="text-red-500">*</span>
              </label>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label htmlFor="dob.day" className="block text-sm text-gray-600 mb-1">Day (DD)</label>
                  <select
                    id="dob.day"
                    name="dob.day"
                    value={formData.dob.day}
                    onChange={handleChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="">Select</option>
                    {[...Array(31)].map((_, i) => (
                      <option key={i} value={String(i + 1).padStart(2, '0')}>
                        {String(i + 1).padStart(2, '0')}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="dob.month" className="block text-sm text-gray-600 mb-1">Month (MM)</label>
                  <select
                    id="dob.month"
                    name="dob.month"
                    value={formData.dob.month}
                    onChange={handleChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="">Select</option>
                    {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map((month, i) => (
                      <option key={i} value={month}>{month}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label htmlFor="dob.year" className="block text-sm text-gray-600 mb-1">Year (YYYY)</label>
                  <input
                    type="number"
                    id="dob.year"
                    name="dob.year"
                    value={formData.dob.year}
                    onChange={handleChange}
                    min="1900"
                    max="2024"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>
            </div>
            
            {/* Gender */}
            <div className="mb-6">
              <label className="block text-gray-700 font-bold mb-2">
                What is your sex? <span className="text-red-500">*</span>
              </label>
              <div className="space-y-2">
                {['Male', 'Female', 'Prefer not to say', 'Other'].map((option) => (
                  <div key={option} className="flex items-center">
                    <input
                      type="radio"
                      id={`gender-${option}`}
                      name="gender"
                      value={option}
                      checked={formData.gender === option}
                      onChange={handleChange}
                      required
                      className="mr-2"
                    />
                    <label htmlFor={`gender-${option}`}>{option}</label>
                  </div>
                ))}
                {formData.gender === 'Other' && (
                  <input
                    type="text"
                    name="genderOther"
                    value={formData.genderOther}
                    onChange={handleChange}
                    placeholder="Please specify"
                    className="w-full mt-2 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                )}
              </div>
            </div>
            
            {/* Education Level */}
            <div className="mb-6">
              <label className="block text-gray-700 font-bold mb-2">
                Last education level
              </label>
              <div className="space-y-2">
                {['School certificate', 'College certificate', 'University certificate', 'Master degree', 'PhD', 'Not in education path', 'Other'].map((option) => (
                  <div key={option} className="flex items-center">
                    <input
                      type="radio"
                      id={`education-${option}`}
                      name="education"
                      value={option}
                      checked={formData.education === option}
                      onChange={handleChange}
                      className="mr-2"
                    />
                    <label htmlFor={`education-${option}`}>{option}</label>
                  </div>
                ))}
                {formData.education === 'Other' && (
                  <input
                    type="text"
                    name="educationOther"
                    value={formData.educationOther}
                    onChange={handleChange}
                    placeholder="Please specify"
                    className="w-full mt-2 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                )}
              </div>
            </div>
            
            {/* Email */}
            <div className="mb-6">
              <label htmlFor="email" className="block text-gray-700 font-bold mb-2">
                Enter your e-mail address
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </motion.div>
          
          {/* First Time Survey */}
          <motion.div variants={itemVariants} className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4">Survey Information</h2>
            
            <div className="mb-6">
              <label className="block text-gray-700 font-bold mb-2">
                Is this your first time you are doing this Survey? <span className="text-red-500">*</span>
              </label>
              <p className="text-sm text-gray-600 mb-2">
                You can do this survey 1 time every 3 months if you wish.
                (we advise you to use only one email to record your neural fingerprint with us for better data quality.)
              </p>
              <div className="space-y-2">
                {['YES', 'NO'].map((option) => (
                  <div key={option} className="flex items-center">
                    <input
                      type="radio"
                      id={`firstTime-${option}`}
                      name="firstTime"
                      value={option}
                      checked={formData.firstTime === option}
                      onChange={handleChange}
                      required
                      className="mr-2"
                    />
                    <label htmlFor={`firstTime-${option}`}>{option}</label>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
          
          {/* Tech Questions */}
          <motion.div variants={itemVariants} className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-2xl font-bold mb-4">AI Technology Questions</h2>
            
            {/* Added Tech */}
            <div className="mb-8">
              <label className="block text-gray-700 font-bold mb-2">
                Have you ever added any techs supplies/substances/items/tools to yourself? <span className="text-red-500">*</span>
              </label>
              <p className="text-sm text-gray-600 mb-2">
                e.g. nanorobot, brain chips, medical capsules, smart lenses... etc
              </p>
              <div className="space-y-2">
                {['YES', 'NO', 'Prefer not to say', 'Other'].map((option) => (
                  <div key={option} className="flex items-center">
                    <input
                      type="radio"
                      id={`addedTech-${option}`}
                      name="addedTech"
                      value={option}
                      checked={formData.addedTech === option}
                      onChange={handleChange}
                      required
                      className="mr-2"
                    />
                    <label htmlFor={`addedTech-${option}`}>{option}</label>
                  </div>
                ))}
                {formData.addedTech === 'Other' && (
                  <input
                    type="text"
                    name="addedTechOther"
                    value={formData.addedTechOther}
                    onChange={handleChange}
                    placeholder="Please specify"
                    className="w-full mt-2 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                )}
              </div>
              
              <div className="mt-4">
                <label htmlFor="addedTechComments" className="block text-gray-700 font-bold mb-2">
                  Comments:
                </label>
                <textarea
                  id="addedTechComments"
                  name="addedTechComments"
                  value={formData.addedTechComments}
                  onChange={handleChange}
                  rows="4"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                ></textarea>
              </div>
            </div>
            
            {/* Agree to Add */}
            <div className="mb-8">
              <label className="block text-gray-700 font-bold mb-2">
                With the accelerated AI development. If you get the chance -In the future- to add techno devices, tools, chips or Nanorobots to yourself, for whatever reason, do you agree? <span className="text-red-500">*</span>
              </label>
              <div className="space-y-2">
                {['Strongly agree', 'Agree', 'I don\'t know', 'Disagree', 'Strongly disagree'].map((option) => (
                  <div key={option} className="flex items-center">
                    <input
                      type="radio"
                      id={`agreeToAdd-${option}`}
                      name="agreeToAdd"
                      value={option}
                      checked={formData.agreeToAdd === option}
                      onChange={handleChange}
                      required
                      className="mr-2"
                    />
                    <label htmlFor={`agreeToAdd-${option}`}>{option}</label>
                  </div>
                ))}
              </div>
              
              <div className="mt-4">
                <label htmlFor="agreeToAddComments" className="block text-gray-700 font-bold mb-2">
                  Comments:
                </label>
                <textarea
                  id="agreeToAddComments"
                  name="agreeToAddComments"
                  value={formData.agreeToAddComments}
                  onChange={handleChange}
                  rows="4"
                  className="
(Content truncated due to size limit. Use line ranges to read in chunks)