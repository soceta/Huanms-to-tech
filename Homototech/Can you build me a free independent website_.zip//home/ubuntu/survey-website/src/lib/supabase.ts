import { createClient } from '@supabase/supabase-js';

// These will be replaced with actual values during deployment
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Survey response interface
export interface SurveyResponse {
  id?: string;
  created_at?: string;
  name: string;
  dob_day: string;
  dob_month: string;
  dob_year: string;
  gender: string;
  gender_other?: string;
  education?: string;
  education_other?: string;
  email?: string;
  first_time: string;
  added_tech: string;
  added_tech_other?: string;
  added_tech_comments?: string;
  agree_to_add: string;
  agree_to_add_comments?: string;
  fear_level: string;
}

// Function to save survey response
export async function saveSurveyResponse(data: SurveyResponse) {
  const { data: response, error } = await supabase
    .from('survey_responses')
    .insert([data])
    .select();
  
  if (error) {
    throw new Error(error.message);
  }
  
  return response;
}

// Function to get all survey responses (for admin)
export async function getSurveyResponses() {
  const { data, error } = await supabase
    .from('survey_responses')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) {
    throw new Error(error.message);
  }
  
  return data;
}

// Function to check admin credentials
export async function checkAdminCredentials(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  
  if (error) {
    throw new Error(error.message);
  }
  
  return data;
}
