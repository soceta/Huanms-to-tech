CREATE TABLE survey_responses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  name TEXT NOT NULL,
  dob_day TEXT NOT NULL,
  dob_month TEXT NOT NULL,
  dob_year TEXT NOT NULL,
  gender TEXT NOT NULL,
  gender_other TEXT,
  education TEXT,
  education_other TEXT,
  email TEXT,
  first_time TEXT NOT NULL,
  added_tech TEXT NOT NULL,
  added_tech_other TEXT,
  added_tech_comments TEXT,
  agree_to_add TEXT NOT NULL,
  agree_to_add_comments TEXT,
  fear_level TEXT NOT NULL
);

-- Create admin users table
CREATE TABLE admin_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert a default admin user (password will be set during setup)
INSERT INTO admin_users (email, password_hash) 
VALUES ('admin@homototech.com', 'placeholder_hash_to_be_replaced');

-- Create row level security policies
ALTER TABLE survey_responses ENABLE ROW LEVEL SECURITY;

-- Only authenticated users can view responses
CREATE POLICY "Allow authenticated users to view responses" 
  ON survey_responses FOR SELECT 
  USING (auth.role() = 'authenticated');

-- Anyone can insert responses
CREATE POLICY "Allow anyone to insert responses" 
  ON survey_responses FOR INSERT 
  WITH CHECK (true);

-- Only authenticated users can update or delete responses
CREATE POLICY "Only authenticated users can update responses" 
  ON survey_responses FOR UPDATE 
  USING (auth.role() = 'authenticated');

CREATE POLICY "Only authenticated users can delete responses" 
  ON survey_responses FOR DELETE 
  USING (auth.role() = 'authenticated');
